// // ReviewPage.jsx
// import React, { useEffect, useState } from 'react';
// import { useLocation } from 'react-router-dom';

// const ReviewPage = () => {
//   const [reviews, setReviews] = useState([]);
//   const location = useLocation();

//   useEffect(() => {
//     const searchParams = new URLSearchParams(location.search);
//     const productUrl = searchParams.get('url');

//     // Mocking fetching reviews from the provided URL
//     fetchReviews(productUrl);
//   }, [location.search]);

//   const fetchReviews = (productUrl) => {
//     // Here you would typically make an API call to fetch reviews
//     // For this example, I'm just mocking the data
//     const mockReviews = [
//       'Design: Sleek and stylish design with premium materials.',
//       'Display: Vibrant and sharp OLED display with True Tone technology.',
//       'Performance: Blazing fast performance thanks to the latest A-series chip.',
//       'Camera: Excellent camera quality with impressive low-light performance and advanced photography features.',
//       'Battery Life: Improved battery life compared to previous models, but may still require daily charging with heavy usage.',
//       'Software: Smooth and intuitive user experience with regular updates and a wide range of apps available on the App Store.',
//       'Security: Enhanced security features such as Face ID for biometric authentication and robust privacy settings.',
//       'Connectivity: Fast 5G connectivity for faster download and streaming speeds (on compatible models).',
//       'Price: Premium pricing compared to other smartphones on the market, but offers great value for its features and performance.',
//       'Overall: The iPhone delivers a premium smartphone experience with top-notch build quality, performance, and features, making it a popular choice among users worldwide.'
//     ];
//     setReviews(mockReviews);
//   };

//   return (
//     <div classNameName='review-container'>
//       <h1>Product Reviews</h1>
//       <ul classNameName='reviews'>
//         {reviews.map((review, index) => (
//           <li key={index}>{review}</li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default ReviewPage;

// ReviewPage.jsx
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import testReviews from "../reviews.json";
import "./ReviewPage.css";
import Rating from '@mui/material/Rating';

const ReviewPage = () => {
  const [reviews, setReviews] = useState([]);
  const location = useLocation();

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const productUrl = searchParams.get("url");

    // Fetch reviews from JSON file
    fetchReviews(productUrl);
  }, [location.search]);

  const fetchReviews = async (productUrl) => {
    try {
      // Fetch reviews from the provided URL
      // const response = await fetch(productUrl);
      // const data = await response.json();
      // Extract reviews data
      // const reviewsData = data.data;
      // const testData = testReviews.data
      // console.log(testData)
      // Set reviews state
      // setReviews(testData);
    } catch (error) {
      console.error("Error fetching reviews:", error);
    }
  };

  return (
    // <div classNameName='review-container'>
    //   <h1>Product Reviews</h1>
    //   <ul classNameName='reviews'>
    //     {testReviews.data.map((review, index) => (
    //       <li key={index}>
    //         Rating: {review.rating}, Review: {review.review}
    //       </li>
    //     ))}
    //   </ul>
    // </div>
    <section className="testimonials">
      <div className="section-header">
        <h2 className="title">Product Reviews</h2>
      </div>
      <div className="testimonials-content">
        <div className="testimonials-slider js-testimonials-slider">
          <div>
            {testReviews.data.map((review, index) => {
              return (
                <div className="testimonials-item">
                  <div className="info">
                    <img
                      src="https://nurserylive.com/cdn/shop/products/nurserylive-plants-rose-red-plant-16969265840268_700x700.jpg?v=1674656824"
                      alt="img"
                    />
                    <div className="" text-box>
                      <h3 className="name">Aswin A</h3>
                      <span className="" job>
                        Awesome
                      </span>
                    </div>
                  </div>
                  <p>{review.review}</p>
                  <Rating name="read-only" value={review.rating} readOnly />

                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ReviewPage;
